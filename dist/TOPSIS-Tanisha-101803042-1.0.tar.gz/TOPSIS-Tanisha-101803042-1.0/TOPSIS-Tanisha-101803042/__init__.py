#from topsis import rank
__version__='1.0'
