#from topsis import rank
__version__='1.1'
